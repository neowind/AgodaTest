﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Agoda.Controllers;
using Agoda.Models;
using Agoda.Repositories;

namespace Agoda.Tests
{
    using NUnit.Framework;

    public class MockRepository : IHotelRepository
    {
        List<Hotel> IHotelRepository.fetchHotels()
        {
            var hotelList = new List<Hotel>
            {
                new Hotel
                {
                    ID = 0,
                    Location = "Bangkok",
                    LowestPrice = 120,
                    Name = "Dusit",
                    Rating = 3.75
                },
                new Hotel
                {
                    ID = 1,
                    Location = "Lei",
                    LowestPrice = 175,
                    Name = "Pai",
                    Rating = 2.5
                }
            };
            return hotelList;
        }
    }

    [TestFixture]
    class DefaultControllerTest
    {
        private DefaultController _controller;

        [SetUp]
        public void Setup()
        {
            var mockRepository = new MockRepository();
            _controller = new DefaultController(mockRepository);
        }

        [TearDown]
        public void TearDown()
        {
            // Do nothing
        }

        [Test]
        public void TestStatic()
        {
            var result = _controller.Static() as ViewResult;
            Assert.NotNull(result);

            var hotelList = result.Model as List<Hotel>;
            Assert.NotNull(hotelList);
            Assert.AreEqual(hotelList.Count, 2);

            Assert.AreEqual(hotelList[0].ID, 0);
            Assert.AreEqual(hotelList[0].Location, "Bangkok");
            Assert.AreEqual(hotelList[0].LowestPrice, 120);
            Assert.AreEqual(hotelList[0].Name, "Dusit");
            Assert.AreEqual(hotelList[0].Rating, 3.75);

            Assert.AreEqual(hotelList[1].ID, 1);
            Assert.AreEqual(hotelList[1].Location, "Lei");
            Assert.AreEqual(hotelList[1].LowestPrice, 175);
            Assert.AreEqual(hotelList[1].Name, "Pai");
            Assert.AreEqual(hotelList[1].Rating, 2.5);
        }

        [Test]
        public void TestAjax()
        {
            var result = _controller.Ajax() as ViewResult;
            Assert.Null(result.Model);
        }
    }
}
